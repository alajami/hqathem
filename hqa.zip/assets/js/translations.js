i18next.use(i18nextHttpBackend).init({
  lng: 'en', // Initial language
  backend: {
    loadPath: '/locales/{{lng}}/{{ns}}.json'
  }
  // Additional configuration...
}, function(err, t) {
  // Callback when initialization is complete
  updateContent();
});

function updateContent() {
  document.getElementById('welcome').innerText = i18next.t('welcome');
  document.getElementById('description').innerText = i18next.t('description');
  // Change text direction
  document.dir = i18next.dir();
}